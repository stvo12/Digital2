/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//#include "fatfs_sd.h"
#include "ili9341.h"
#include "stdio.h"
#include "stdbool.h"
#include "string.h"
#include "Bitmaps.h"

/*FATFS fs;
FIL fil;
FRESULT fres;*/
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

typedef enum {
    IDLE,
    MOVER_IZQ,
    MOVER_DER,
    MOVER_ARRIBA,
	MOVER_ABAJO,
    ATAQUE_ARRIBA,
	ATAQUE_ABAJO,
    ATAQUE_IZQ,
    ATAQUE_DER,
    DEFENSA
} EstadoJ1,EstadoJ2;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
uint8_t rxbuff5;
uint8_t rxbuff4;
uint8_t dataB5, dataC5, dataB4, dataC4;
uint8_t flag5 = 0, flag4 = 0;
uint8_t Stage = 0;

int X1 = 80;
int Y1 = 100;
int X2 = 150;
int Y2 = 100;
int vida1 = 3;
int vida2 = 3;
int defensa1 = 1;
int defensa2 = 1;

int healthX1 = 5;
int healthY1 = 5;
int frame_vida1 = 1;

int prevX1 = 100;
int prevY1 = 100;
int prevX2 = 150;
int prevY2 = 100;

#define BG 0x120F

#define W1_SPR 35
#define H1_SPR 35
#define W2_SPR 35
#define H2_SPR 35

#define max(a,b)  ( ( (a) > (b) ) ? (a) : (b) )
#define min(a,b)  ( ( (a) < (b) ) ? (a) : (b) )

static int framecounter1 = 0;
static int framecounter2 = 0;
static int framecounter3 = 0;

#define SCREEN_W     320
#define SCREEN_H     240
#define BG_BASE      0x1B75 // #1C6DB0 → R=3,G=27,B=21 en RGB565
#define BG_BORDER    0xFFFF // blanco

int V1 = 2;
int V2 = 2;

bool colision_detected = false;

#define BORDE_IZQ 42
#define BORDE_DER 320-42
#define BORDE_UP 42
#define BORDE_DOWN 240-42

#define sprite_up_g1 gallina1Up
#define sprite_down_g1 gallina1Down
#define sprite_left_g1 gallina1Left
#define sprite_IDLE_g1 gallina1IDLE
#define sprite_attizq_g1 gallina1_ATACAR_IZQ
#define sprite_attup_g1 gallina1_ATACAR_UP
#define sprite_attdown_g1 gallina1_ATACAR_DOWN
#define sprite_defense_g1 gallina1_DEFENSE

#define sprite_up_g gallinaUp
#define sprite_down_g gallinaDown
#define sprite_left_g gallinaLeft
#define sprite_IDLE_g gallinaIDLE
#define sprite_attizq_g gallina_ATACAR_IZQ
#define sprite_attup_g gallina_ATACAR_UP
#define sprite_attdown_g gallina_ATACAR_DOWN
#define sprite_defense_g gallina_DEFENSE

EstadoJ1 estado_actual = IDLE; //propiedades del J1
EstadoJ2 estado_actual2 = IDLE; //propiedades del J2

#define FONDO_ANCHO  320
#define FONDO_ALTO   240
#define FONDO_TAM    (FONDO_ANCHO * FONDO_ALTO * 2) // RGB565
//uint8_t fondo_buffer[FONDO_TAM];

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart5;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
extern unsigned char fondo[];
extern unsigned char fondoInit[];
extern unsigned char fondoG1[];
extern unsigned char fondoG2[];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_UART4_Init(void);
static void MX_UART5_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

static bool collision(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2)
{
    return (x1 < x2 + w2) &&
           (x1 + w1 > x2) &&
           (y1 < y2 + h2) &&
           (y1 + h1 > y2);
}

void transmit_uart(char *string){
	uint8_t len = strlen(string);
	HAL_UART_Transmit(&huart2, (uint8_t*) string, len, 200);
}

/*void cargarFondoDesdeSD(const char* archivo) {
    UINT leidos;
    uint8_t* fondo_buffer = malloc(FONDO_TAM); // reservar 150 KB

    fres = f_mount(&fs, "", 1);
    if (fres != FR_OK) {
        transmit_uart("Error al montar SD\n");
        free(fondo_buffer);
        return;
    }

    fres = f_open(&fil, archivo, FA_READ);
    if (fres != FR_OK) {
        transmit_uart("Error al abrir fondo\n");
        f_mount(NULL, "", 1);
        free(fondo_buffer);
        return;
    }

    fres = f_read(&fil, fondo_buffer, FONDO_TAM, &leidos);
    if (fres == FR_OK && leidos == FONDO_TAM) {
        transmit_uart("Fondo cargado OK\n");
        LCD_Bitmap(0, 0, FONDO_ANCHO, FONDO_ALTO, fondo_buffer);
    } else {
        transmit_uart("Error leyendo fondo\n");
    }

    f_close(&fil);
    f_mount(NULL, "", 1);
    free(fondo_buffer);
}*/

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_USART2_UART_Init();
  MX_UART4_Init();
  MX_UART5_Init();
  /* USER CODE BEGIN 2 */

  HAL_UART_Receive_IT(&huart5, &rxbuff5, 1);
  HAL_UART_Receive_IT(&huart4, &rxbuff4, 1);

	LCD_Init();

	LCD_Clear(0x00);
	LCD_Bitmap(0,0,320,240,fondoInit);
	//cargarFondoDesdeSD("FondoStart.bmp");
	//LCD_Bitmap(0,0,320,240,fondoInit);
	//LCD_Bitmap(0,0,320,240,fondoG1);
	//LCD_Bitmap(0,0,320,240,fondoG2);

	//void LCD_Sprite(int x, int y, int width, int height, unsigned char bitmap[], int columns, int index, char flip, char offset);
	//LCD_Sprite(100,125, 50, 50, gallina2, 4, 3, 0, 0);
	// FillRect(0, 0, 319, 206, 0x1911);

	//  LCD_Print("Hola Mundo", 20, 100, 1, 0xi001F, 0xCAB9);
	bool
		        fUp      = false,
		        fDown    = false,
		        fLeft    = false,
		        fRight   = false,
		        fAttack  = false,
		        fDefense = false,
		        fUp2     = false,
		        fDown2   = false,
		        fLeft2   = false,
		        fRight2  = false,
				fAttack2 = false,
				fDefense2 = false;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */



	while (1)
	{


		framecounter1 = (framecounter1 + 1)%4;

	    //uint8_t cmd;
	    // dentro de tu while, reemplaza esa sección por:



	    /* ----------------- JUGADOR 1 ----------------- */
		if (flag5) {
		  transmit_uart("Jugador 1: ");
		  flag5 = 0; // Limpiamos flag

		  if (rxbuff5 == 0x42) { // 'B'
			  HAL_UART_Receive(&huart5, &dataB5, 1, HAL_MAX_DELAY);
			  if (dataB5 == 0x01){
				  transmit_uart("X\n");
				  switch (Stage){
				  case 0:
					  vida1 = 3;
					  vida2 = 3;
					  Stage++;
					  LCD_Bitmap(0,0,320,240,fondo);
					  //cargarFondoDesdeSD("Fondo.raw");
					  break;
				  case 1:
					  break;
				  case 2:
					  Stage = 0;
					  LCD_Bitmap(0,0,320,240,fondoInit);
					  //cargarFondoDesdeSD("FondoG1.raw");
					  break;
				  case 3:
					  Stage = 0;
					  LCD_Bitmap(0,0,320,240,fondoInit);
					  //cargarFondoDesdeSD("FondoG2.raw");
					  break;
				  }

			  }
			  else if (dataB5 == 0x02){
				  transmit_uart("O\n");
				  fAttack  = false;
				  fDefense = true;
			  }
			  else if (dataB5 == 0x04){
				  transmit_uart("C\n");
				  fAttack  = true;
				  fDefense = false;
			  }
			  else{
				  transmit_uart("null\n");
				  fAttack  = false;
				  fDefense = false;
			  }
		  }
		  else if (rxbuff5 == 0x43) { // 'C'
			  HAL_UART_Receive(&huart5, &dataC5, 1, HAL_MAX_DELAY);
			  if (dataC5 == 0x01){
				  transmit_uart("Arr\n");
				  fUp      = true;
				  fDown    = false;
				  fLeft    = false;
				  fRight   = false;
			  }
			  else if (dataC5 == 0x02){
				  transmit_uart("Aba\n");
				  fUp      = false;
				  fDown    = true;
				  fLeft    = false;
				  fRight   = false;
			  }
			  else if (dataC5 == 0x04){
				  transmit_uart("Der\n");
				  fUp      = false;
				  fDown    = false;
				  fLeft    = false;
				  fRight   = true;
			  }
			  else if (dataC5 == 0x08){
				  transmit_uart("Izq\n");
				  fUp      = false;
				  fDown    = false;
				  fLeft    = true;
				  fRight   = false;
			  }
			  else{
				  transmit_uart("null\n");
				  fUp      = false;
				  fDown    = false;
				  fLeft    = false;
				  fRight   = false;
			  }
		  }

		  /* Volvemos a activar interrupción */
		  HAL_UART_Receive_IT(&huart5, &rxbuff5, 1);
		}

		/* ----------------- JUGADOR 2 ----------------- */
		if (flag4) {
		  transmit_uart("Jugador 2: ");
		  flag4 = 0; // Limpiamos flag

		  if (rxbuff4 == 0x42) { // 'B'
			  HAL_UART_Receive(&huart4, &dataB4, 1, HAL_MAX_DELAY);
			  if (dataB4 == 0x01){
				  transmit_uart("X\n");
			  }
			  else if (dataB4 == 0x02){
				  transmit_uart("O\n");
				  fAttack2  = false;
				  fDefense2 = true;
			  }
			  else if (dataB4 == 0x04){
				  transmit_uart("C\n");
				  fAttack2  = true;
				  fDefense2 = false;
			  }
			  else{
				  transmit_uart("null\n");
				  fAttack2  = false;
				  fDefense2 = false;
			  }
		  }
		  else if (rxbuff4 == 0x43) { // 'C'
			  HAL_UART_Receive(&huart4, &dataC4, 1, HAL_MAX_DELAY);
			  if (dataC4 == 0x01){
				  transmit_uart("Arr\n");
				  fUp2      = true;
				  fDown2    = false;
				  fLeft2    = false;
				  fRight2   = false;
			  }
			  else if (dataC4 == 0x02){
				  transmit_uart("Aba\n");
				  fUp2      = false;
				  fDown2    = true;
				  fLeft2    = false;
				  fRight2   = false;
			  }
			  else if (dataC4 == 0x04){
				  transmit_uart("Der\n");
				  fUp2      = false;
				  fDown2    = false;
				  fLeft2    = false;
				  fRight2   = true;
			  }
			  else if (dataC4 == 0x08){
				  transmit_uart("Izq\n");
				  fUp2      = false;
				  fDown2    = false;
				  fLeft2    = true;
				  fRight2   = false;
			  }
			  else{
				  transmit_uart("null\n");
				  fUp2      = false;
				  fDown2    = false;
				  fLeft2    = false;
				  fRight2   = false;
			  }
		  }

		  /* Volvemos a activar interrupción */
		  HAL_UART_Receive_IT(&huart4, &rxbuff4, 1);
		}

		switch (Stage){
		case 0: break;
		case 1:

			if (vida2 == 3){
						//  LCD_Print(char *text, int x, int y, int fontSize, int color,int background)
						LCD_Print("3 J2", 30, 3, 2, 0xFFFF, 0x0000 );
					}
					else if(vida2 ==2){
						LCD_Print("2 J2", 30, 3, 2, 0xFFFF, 0x0000 );
					}
					else if(vida2 == 1) {
						LCD_Print("1 J2", 30, 3, 2, 0xFFFF, 0x0000 );
					}
					else{
						if ((vida1 > vida2) && vida2 == 0){
							LCD_Print("GAME OVER:WINNER J1", 5, 210,2, 0xFFFF, 0x0000 );
							Stage = 2;
							break;
						}

					}

					if (vida1 == 3){
						//  LCD_Print("Hola Mundo", 20, 100, 1, 0xi001F, 0xCAB9);
						LCD_Print("3 J1", 235, 3, 2, 0xFFFF, 0x0000 );
					}
					else if(vida1 ==2){
						LCD_Print("2 J1", 235, 3, 2, 0xFFFF, 0x0000 );
					}
					else if(vida1 == 1) {
						LCD_Print("1 J1", 235, 3, 2, 0xFFFF, 0x0000 );
					}
					else{
						if ((vida2 > vida1) && vida1 == 0){
							 LCD_Print("GAME OVER:WINNER J2", 5, 210,2, 0xFFFF, 0x0000 );
							 Stage = 3;
							break;
						}
						//break;
					}

				    if (collision(X1, Y1, W1_SPR, H1_SPR,
				                    X2, Y2, W2_SPR, H2_SPR))
				    {
				        // ejemplo de respuesta al choque:
				        if (X1 < X2) {
				        		//FillRect(X1+W1_SPR,Y1,4,H1_SPR,BG_BASE);
				            X1 = max(X1 - V1, BORDE_IZQ);
				            X2 = min(X2 + V2, BORDE_DER - W2_SPR);
				            colision_detected = true;


				        } else {
				            X1 = min(X1 + V1, BORDE_DER - W1_SPR);
				            X2 = max(X2 - V2, BORDE_IZQ);
				            colision_detected = false;
				        }
				    }

			framecounter1 = (framecounter1 + 1)%8;
			framecounter2 = (framecounter2 + 1)%2;
			framecounter3 = (framecounter3 + 1)%3;

			if (fDefense||fDefense2)//prioridad
					{
					   if (fDefense) {estado_actual = DEFENSA;}
					   else {estado_actual2 = DEFENSA;}

					}

			else if ((fUp||fDown||fLeft||fRight) && fAttack)
					{
						if      (fUp)  {  estado_actual = ATAQUE_ARRIBA;}
						else if (fDown) { estado_actual = ATAQUE_ABAJO;}
						else if (fLeft) { estado_actual = ATAQUE_IZQ;}
						else            {  estado_actual = ATAQUE_DER; }

						fAttack = false;
					}


			else if((fUp2||fDown2||fLeft2||fRight2) && fAttack2){
						if      (fUp2)  {  estado_actual2 = ATAQUE_ARRIBA;}
						else if (fDown2) { estado_actual2 = ATAQUE_ABAJO;}
						else if (fLeft2) { estado_actual2 = ATAQUE_IZQ;}
						else          {    estado_actual2 = ATAQUE_DER;}

						fAttack2 = false;
					}

			else if (fUp||fDown||fLeft||fRight||fUp2||fDown2||fLeft2||fRight2)
					{
						if      (fUp){    estado_actual = MOVER_ARRIBA;}
						else if (fUp2){    estado_actual2 = MOVER_ARRIBA;}

						else if (fDown){  estado_actual = MOVER_ABAJO;}
						else if (fDown2){  estado_actual2 = MOVER_ABAJO;}

						else if (fLeft){  estado_actual = MOVER_IZQ;}
						else if (fLeft2){  estado_actual2 = MOVER_IZQ;}

						else if (fRight){         estado_actual = MOVER_DER;}
						else if (fRight2){         estado_actual2 = MOVER_DER;}
					}
			else
					{
						estado_actual = IDLE;
						estado_actual2 = IDLE;
					}

			//prueba
			if (X1 < BORDE_IZQ){
				X1 = BORDE_IZQ;
				//void V_line(unsigned int x, unsigned int y, unsigned int l, unsigned int c)
				FillRect(X1-3,Y1,3,H1_SPR,BG_BASE);
			}
			else if(X1 + W1_SPR > BORDE_DER){
				X1 = BORDE_DER - W1_SPR;
				//void Rect(unsigned int x, unsigned int y, unsigned int w, unsigned int h,unsigned int c)
				FillRect(X1+W1_SPR,Y1,4,H1_SPR,BG_BASE);
			}
			else if (Y1 < BORDE_UP){
				Y1 = BORDE_UP;
				FillRect(X1,Y1-3, W1_SPR, 3, BG_BASE);
			}
			else if (Y1+H1_SPR > BORDE_DOWN){
				Y1 = BORDE_DOWN - H1_SPR;
				FillRect(X1,Y1+H1_SPR, W1_SPR, 3, BG_BASE);
			}
	//COLISION 1
			if (X2 < BORDE_IZQ){
				X2 = BORDE_IZQ;
				//void V_line(unsigned int x, unsigned int y, unsigned int l, unsigned int c)
				FillRect(X2-3,Y2,3,H2_SPR,BG_BASE);
			}
			else if(X2 + W2_SPR > BORDE_DER){
				X2 = BORDE_DER - W2_SPR;
				//void Rect(unsigned int x, unsigned int y, unsigned int w, unsigned int h,unsigned int c)
				FillRect(X2+W2_SPR,Y2,4,H2_SPR,BG_BASE);
			}
			else if (Y2 < BORDE_UP){
				Y2 = BORDE_UP;
				FillRect(X2,Y2-3, W2_SPR, 3, BG_BASE);
			}
			else if (Y2+H2_SPR > BORDE_DOWN){
				Y2 = BORDE_DOWN - H2_SPR;
				FillRect(X2,Y1+H2_SPR, W2_SPR, 3, BG_BASE);
			}


			//termina prueba
			//prueba 2
			if (X1 + W1_SPR+1 == X2){
				X1 = X1 - W1_SPR;
			}
			//termina prueba 2

			if (X2 + W2_SPR < X1){
				    	FillRect(X1-3,Y1,3,H1_SPR,BG_BASE);
				    	FillRect(X2+W2_SPR, Y2, 3, H2_SPR, BG_BASE);
				    }

				    else if (X1 + W1_SPR < X2){
				    	FillRect(X2+W2_SPR,Y2,3,H2_SPR,BG_BASE);
				    	FillRect(X2-3, Y2, 3, H2_SPR, BG_BASE);
				    }
				    //termina prueba 2

			switch (estado_actual)
			{
				case MOVER_ARRIBA:
					Y1 -= V1;
				   // LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X1,Y1,W1_SPR,H1_SPR,gallinaUp,4,framecounter1,0,0);
					break;
				case MOVER_ABAJO:
					Y1 += V1;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					FillRect(X1,Y1,3,W1_SPR,BG_BASE);
					LCD_Sprite(X1,Y1,W1_SPR,H1_SPR,gallinaDown,4,framecounter1,0,0);
					break;
				case MOVER_IZQ:
					X1 -= V1;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X1,Y1,W1_SPR,H1_SPR,gallinaLeft,4,framecounter1,0,0);
					break;
				case MOVER_DER:
					X1 += V1;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 1, 0);
					LCD_Sprite(X1,Y1,W1_SPR,H1_SPR,gallinaLeft,4,framecounter1,1,0);
					//void V_line(unsigned int x, unsigned int y, unsigned int l, unsigned int c)
					//V_line(X1-1, Y1, 35, BG_BASE);
					break;

				case ATAQUE_ARRIBA:
					Y1 -= V1;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X1,Y1,W1_SPR,H1_SPR,sprite_attup_g1,4,framecounter1,0,0);
					if (colision_detected){
						if (estado_actual2 == DEFENSA){
							defensa2 --;
							if (defensa2 == 0){vida2--;}
						}else{vida2--;}
					}

					break;
				case ATAQUE_ABAJO:
					Y1 += V1;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X1,Y1,W1_SPR,H1_SPR,sprite_attdown_g,4,framecounter1,0,0);
					if (colision_detected){
						if (estado_actual2 == DEFENSA){
							defensa2 --;
							if (defensa2 == 0){vida2--;}
						}else{vida2--;}
					}
					break;
				case ATAQUE_IZQ:
					X1 -= V1;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 1, 0);
					LCD_Sprite(X1,Y1,W1_SPR,H1_SPR,sprite_attizq_g,4,framecounter1,0,0);
					if (colision_detected){
						if (estado_actual2 == DEFENSA){
							defensa2 --;
							if (defensa2 == 0){vida2--;}
						}else{vida2--;}
					}
					break;
				case ATAQUE_DER:
					X1 += V1;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X1,Y1,W1_SPR,H1_SPR,sprite_attizq_g,4,framecounter1,1,0);
					if (colision_detected){
						if (estado_actual2 == DEFENSA){
							defensa2 --;
							if (defensa2 == 0){vida2--;}
						}else{vida2--;}
					}
					break;

				case DEFENSA:
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Bitmap(X1,Y1,W1_SPR,H1_SPR,sprite_defense_g);
					//LCD_Sprite(X1,Y1,W1_SPR,H1_SPR,sprite_defense_g,1,1,0,0);
					break;

				case IDLE:
				default:
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X1,Y1,W1_SPR,H1_SPR,sprite_IDLE_g,2,framecounter2,0,0);
					break;
			}//jugador 1 termina aca

			switch (estado_actual2)
			{
				case MOVER_ARRIBA:
					Y2 -= V2;
				   // LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X2,Y2,W2_SPR,H2_SPR,sprite_up_g1,4,framecounter1,0,0);
					break;
				case MOVER_ABAJO:
					Y2 += V2;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X2,Y2,W2_SPR,H2_SPR,sprite_down_g1,4,framecounter1,0,0);
					break;
				case MOVER_IZQ:
					X2 -= V2;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X2,Y2,W2_SPR,H2_SPR,sprite_left_g1,4,framecounter1,0,0);
					break;
				case MOVER_DER:
					X2 += V2;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 1, 0);
					LCD_Sprite(X2,Y2,W2_SPR,H2_SPR,sprite_left_g1,4,framecounter1,1,0);
					//void V_line(unsigned int x, unsigned int y, unsigned int l, unsigned int c)
					//V_line(X1-1, Y1, 35, BG_BASE);
					break;

				case ATAQUE_ARRIBA: //Jugador 2
					Y2 -= V2;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X2,Y2,W2_SPR,H2_SPR,sprite_attup_g1,4,framecounter1,0,0);
					if (colision_detected){
						if (estado_actual == DEFENSA){
							defensa1 --;
							if (defensa1 == 0){vida1--;}
						}else{vida1--;}
					}
					break;
				case ATAQUE_ABAJO:
					Y2 += V2;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X2,Y2,W2_SPR,H2_SPR,sprite_attdown_g1,4,framecounter1,0,0);
					if (colision_detected){
						if (estado_actual == DEFENSA){
							defensa1 --;
							if (defensa1 == 0){vida1--;}
						}else{vida1--;}
					}
					break;
				case ATAQUE_IZQ:
					X2 -= V2;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 1, 0);
					LCD_Sprite(X2,Y2,W2_SPR,H2_SPR,sprite_attizq_g1,4,framecounter1,0,0);
					if (colision_detected){
						if (estado_actual == DEFENSA){
							defensa1 --;
							if (defensa1 == 0){vida1--;}
						}else{vida1--;}
					}
					break;
				case ATAQUE_DER:
					X2 += V2;
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X2,Y2,W2_SPR,H2_SPR,sprite_attizq_g1,4,framecounter1,1,0);
					if (colision_detected){
						if (estado_actual == DEFENSA){
							defensa1 --;
							if (defensa1 == 0){vida1--;}
						}else{vida1--;}
					}
					break;

				case DEFENSA:
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					//LCD_Sprite(X2,Y2,W2_SPR,H2_SPR,sprite_defense_g1,2,1,0,0);
					LCD_Bitmap(X2,Y2,W2_SPR,H2_SPR,sprite_defense_g1);
					break;

				case IDLE:
				default:
					//LCD_Sprite(X1, Y1, 50, 46, rooster, 8, framecounter1, 0, 0);
					LCD_Sprite(X2,Y2,W2_SPR,H2_SPR,sprite_IDLE_g1,2,framecounter2,0,0);
					break;
			}
			HAL_Delay(30);
			break;
		case 2:
			//LCD_Bitmap(0,0,320,240,fondoG1);
			//LCD_Print("GAME OVER:WINNER J1", 5, 210,2, 0xFFFF, 0x0000 );
			break;
		case 3:
			//LCD_Bitmap(0,0,320,240,fondoG2);
			//LCD_Print("GAME OVER:WINNER J2", 5, 210,2, 0xFFFF, 0x0000 );
			break;
		}
	}






    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 80;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief UART5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART5_Init(void)
{

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  huart5.Instance = UART5;
  huart5.Init.BaudRate = 115200;
  huart5.Init.WordLength = UART_WORDLENGTH_8B;
  huart5.Init.StopBits = UART_STOPBITS_1;
  huart5.Init.Parity = UART_PARITY_NONE;
  huart5.Init.Mode = UART_MODE_TX_RX;
  huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart5.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LCD_RST_Pin|LCD_D1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin|SD_SS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LCD_RST_Pin LCD_D1_Pin */
  GPIO_InitStruct.Pin = LCD_RST_Pin|LCD_D1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_RD_Pin LCD_WR_Pin LCD_RS_Pin LCD_D7_Pin
                           LCD_D0_Pin LCD_D2_Pin */
  GPIO_InitStruct.Pin = LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_CS_Pin LCD_D6_Pin LCD_D3_Pin LCD_D5_Pin
                           LCD_D4_Pin SD_SS_Pin */
  GPIO_InitStruct.Pin = LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin|SD_SS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == UART5) {
        flag5 = 1; // Señalamos que llegó dato del jugador 1
    }
    else if (huart->Instance == UART4) {
        flag4 = 1; // Señalamos que llegó dato del jugador 2
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
