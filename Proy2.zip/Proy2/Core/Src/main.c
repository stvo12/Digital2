/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "pitches.h"
#include "string.h"
#include "stdio.h"
#include <stdbool.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define TIM_FREQ 60000000
#define ARR 100

char buffer[100];
uint8_t rxbuff5;
uint8_t rxbuff4;
bool boton = false;
bool cruz = false;
uint8_t dataB5, dataC5, dataB4, dataC4;
uint8_t flag5 = 0, flag4 = 0;

bool play_music = false;

// mario
int melody[] = {
659, 659, 659, 0, 523, 659, 784, 392, 523, 0, 392, 0, 330, 0, 440, 0, 494, 0, 466, 440, 392, 659, 784, 880, 698, 784, 0, 659, 0, 523, 587, 494, 0, 523, 0, 392, 0, 330, 0, 440, 0, 494, 0, 466, 440, 392, 659, 784, 880, 698, 784, 0, 659, 0, 523, 587, 494, 0, 0, 784, 740, 698, 622, 659, 0, 415, 440, 523, 0, 440, 523, 587, 0, 784, 740, 698, 622, 659, 0, 698, 1047, 0, 698, 1047, 698, 1047, 0, 784, 740, 698, 622, 659, 0, 415, 440, 523, 0, 440, 523, 587, 0, 622, 0, 587, 0, 523, 0, 0, 784, 740, 698, 622, 659, 0, 415, 440, 523, 0, 440, 523, 587, 0, 784, 740, 698, 622, 659, 0, 698, 1047, 0, 698, 1047, 698, 1047, 0, 784, 740, 698, 622, 659, 0, 415, 440, 523, 0, 440, 523, 587, 0, 622, 0, 587, 0, 523, 0, 523, 523, 523, 0, 523, 587, 659, 523, 440, 392, 523, 523, 523, 0, 523, 587, 659, 0, 523, 523, 523, 0, 523, 587, 659, 523, 440, 392, 659, 659, 659, 0, 523, 659, 784, 392, 523, 0, 392, 0, 330, 0, 440, 0, 494, 0, 466, 440, 392, 659, 784, 880, 698, 784, 0, 659, 0, 523, 587, 494, 0, 523, 0, 392, 0, 330, 0, 440, 0, 494, 0, 466, 440, 392, 659, 784, 880, 698, 784, 0, 659, 0, 523, 587, 494, 0, 659, 523, 392, 0, 415, 440, 698, 698, 440, 494, 880, 880, 880, 784, 698, 659, 523, 440, 392, 659, 523, 392, 0, 415, 440, 698, 698, 440, 494, 698, 698, 698, 659, 587, 523, 392, 392, 262, 523, 523, 523, 0, 523, 587, 659, 523, 440, 392, 523, 523, 523, 0, 523, 587, 659, 0, 523, 523, 523, 0, 523, 587, 659, 523, 440, 392, 659, 659, 659, 0, 523, 659, 784, 392, 659, 523, 392, 0, 415, 440, 698, 698, 440, 494, 880, 880, 880, 784, 698, 659, 523, 440, 392, 659, 523, 392, 0, 415, 440, 698, 698, 440, 494, 698, 698, 698, 659, 587, 523, 392, 392, 262, 0
};
int noteDurations[] = {
126, 252, 126, 126, 126, 252, 504, 504, 252, 126, 126, 252, 252, 126, 126, 126, 126, 126, 126, 252, 168, 168, 168, 252, 126, 126, 126, 126, 126, 126, 126, 126, 252, 252, 126, 126, 252, 252, 126, 126, 126, 126, 126, 126, 252, 168, 168, 168, 252, 126, 126, 126, 126, 126, 126, 126, 126, 252, 252, 126, 126, 126, 252, 126, 126, 126, 126, 126, 126, 126, 126, 126, 252, 126, 126, 126, 252, 126, 126, 126, 126, 126, 126, 126, 504, 504, 252, 126, 126, 126, 252, 126, 126, 126, 126, 126, 126, 126, 126, 126, 252, 252, 126, 126, 252, 504, 504, 252, 126, 126, 126, 252, 126, 126, 126, 126, 126, 126, 126, 126, 126, 252, 126, 126, 126, 252, 126, 126, 126, 126, 126, 126, 126, 504, 504, 252, 126, 126, 126, 252, 126, 126, 126, 126, 126, 126, 126, 126, 126, 252, 252, 126, 126, 252, 504, 504, 126, 252, 126, 126, 126, 252, 126, 252, 126, 504, 126, 252, 126, 126, 126, 126, 126, 1008, 126, 252, 126, 126, 126, 252, 126, 252, 126, 504, 126, 252, 126, 126, 126, 252, 504, 504, 252, 126, 126, 252, 252, 126, 126, 126, 126, 126, 126, 252, 168, 168, 168, 252, 126, 126, 126, 126, 126, 126, 126, 126, 252, 252, 126, 126, 252, 252, 126, 126, 126, 126, 126, 126, 252, 168, 168, 168, 252, 126, 126, 126, 126, 126, 126, 126, 126, 252, 126, 252, 126, 252, 252, 126, 252, 126, 504, 168, 168, 168, 168, 168, 168, 126, 252, 126, 504, 126, 252, 126, 252, 252, 126, 252, 126, 504, 126, 252, 126, 168, 168, 168, 126, 252, 126, 504, 126, 252, 126, 126, 126, 252, 126, 252, 126, 504, 126, 252, 126, 126, 126, 126, 126, 1008, 126, 252, 126, 126, 126, 252, 126, 252, 126, 504, 126, 252, 126, 126, 126, 252, 504, 504, 126, 252, 126, 252, 252, 126, 252, 126, 504, 168, 168, 168, 168, 168, 168, 126, 252, 126, 504, 126, 252, 126, 252, 252, 126, 252, 126, 504, 126, 252, 126, 168, 168, 168, 126, 252, 126, 504, 0
};

int pokemon_intro_melody[] = {
294, 294, 440, 294, 294, 466, 294, 294, 440, 294, 294, 370, 294, 294, 440, 294, 294, 554, 587, 294, 523, 294, 294, 294, 440, 294, 294, 466, 294, 294, 523, 294, 294, 554, 1175, 0, 196, 247, 294, 370, 392, 392, 0, 392, 392, 392, 392, 392, 349, 349, 349, 349, 349, 370, 392, 494, 587, 0, 698, 659, 622, 587, 0, 392, 494, 587, 0, 523, 494, 523, 587, 0, 392, 494, 587, 0, 698, 659, 622, 587, 0, 392, 494, 587, 0, 698, 659, 698, 784, 932, 784, 784, 880, 932, 698, 0, 0, 932, 988, 1047, 784, 0, 0, 1047, 1109, 1175, 0, 1047, 1047, 1109, 1175, 0, 1047, 1047, 988, 0
};

int pokemon_intro_durations[] = {
252, 252, 504, 252, 252, 504, 252, 252, 504, 252, 252, 504, 252, 252, 504, 252, 252, 504, 1008, 1008, 1008, 1008, 252, 252, 504, 252, 252, 504, 252, 252, 504, 252, 252, 504, 504, 1008, 126, 126, 126, 126, 504, 504, 252, 126, 126, 504, 504, 504, 168, 168, 168, 168, 168, 168, 756, 252, 1008, 1008, 756, 126, 126, 1008, 1008, 756, 252, 1008, 1008, 336, 336, 336, 1008, 1008, 756, 252, 1008, 1008, 756, 126, 126, 1008, 1008, 756, 252, 1008, 1008, 336, 336, 336, 672, 336, 1008, 1008, 1008, 756, 1008, 252, 1008, 504, 504, 756, 1008, 252, 1008, 504, 504, 504, 1008, 336, 336, 336, 504, 1008, 336, 336, 336, 0
};

int starwars_melody[] = {
  NOTE_A4, NOTE_A4, NOTE_A4, NOTE_F4, NOTE_C5, NOTE_A4, NOTE_F4, NOTE_C5, NOTE_A4, 0,
  NOTE_E5, NOTE_E5, NOTE_E5, NOTE_F5, NOTE_C5, NOTE_GS4, NOTE_F4, NOTE_C5, NOTE_A4, 0,
  NOTE_A5, NOTE_A4, NOTE_A4, NOTE_A5, NOTE_GS5, NOTE_G5, NOTE_FS5, NOTE_F5, NOTE_FS5, 0,
  NOTE_AS4, NOTE_DS5, NOTE_D5, NOTE_CS5, NOTE_C5, NOTE_B4, NOTE_C5, 0
};

int starwars_durations[] = {
  500, 500, 500, 350, 150, 500, 350, 150, 650, 500,
  500, 500, 500, 350, 150, 500, 350, 150, 650, 500,
  500, 300, 150, 500, 325, 175, 125, 125, 250, 325,
  250, 500, 325, 175, 125, 125, 250, 0
};

int tv_off_melody[] = {
392, 370, 330, 294, 370, 392, 370, 330, 330, 392, 370, 330, 294, 370, 392, 370, 330, 330, 784, 740, 659, 587, 740, 784, 740, 659, 659, 784, 740, 659, 587, 740, 784, 740, 659, 659, 494, 784, 0, 554, 880, 587, 988, 0, 0
};
int tv_off_duration[] = {
504, 504, 504, 378, 126, 504, 504, 504, 504, 504, 504, 504, 378, 126, 504, 504, 504, 504, 504, 504, 504, 378, 126, 504, 504, 504, 504, 504, 504, 504, 378, 126, 504, 504, 504, 504, 252, 252, 252, 252, 252, 252, 252, 1008, 0
};

int MK_melody[] = {
370, 370, 440, 370, 494, 370, 554, 494, 440, 440, 554, 440, 659, 440, 554, 440, 330, 330, 415, 330, 440, 330, 494, 440, 294, 294, 370, 294, 440, 294, 440, 415, 370, 370, 370, 0, 370, 330, 440, 370, 370, 370, 0, 370, 330, 278, 370, 370, 370, 0, 370, 330, 440, 370, 370, 370, 370, 370, 370, 370, 0, 370, 370, 370, 0, 370, 330, 440, 370, 370, 370, 0, 370, 330, 278, 370, 370, 370, 0, 370, 330, 440, 370, 370, 370, 370, 370, 370, 370, 0, 370, 554, 370, 440, 370, 392, 370, 440, 370, 392, 330, 370, 554, 370, 440, 370, 392, 370, 440, 370, 392, 330, 370, 554, 370, 440, 330, 330, 330, 370, 370, 0, 370, 554, 370, 440, 370, 392, 370, 440, 370, 392, 330, 370, 554, 370, 440, 370, 392, 370, 440, 370, 392, 330, 370, 554, 370, 440, 330, 330, 330, 370, 370, 0, 370, 370, 440, 370, 494, 370, 554, 494, 440, 440, 554, 440, 659, 440, 554, 440, 330, 330, 415, 330, 440, 330, 494, 440, 294, 294, 370, 294, 440, 294, 440, 415, 370, 370, 440, 370, 494, 370, 554, 494, 440, 440, 554, 440, 659, 440, 554, 440, 330, 330, 415, 330, 440, 330, 494, 440, 294, 294, 370, 294, 440, 294, 440, 415, 0
};
int MK_durations[] = {
250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 375, 375, 250, 125, 375, 250, 250, 375, 375, 250, 125, 375, 250, 250, 375, 375, 250, 125, 375, 250, 250, 375, 375, 250, 125, 250, 125, 250, 250, 375, 375, 250, 125, 375, 250, 250, 375, 375, 250, 125, 375, 250, 250, 375, 375, 250, 125, 375, 250, 250, 375, 375, 250, 125, 250, 125, 250, 250, 125, 250, 125, 250, 125, 250, 125, 250, 125, 125, 250, 125, 250, 125, 250, 125, 250, 125, 250, 125, 125, 250, 125, 250, 125, 250, 125, 250, 125, 250, 250, 250, 125, 250, 125, 250, 125, 250, 125, 250, 125, 125, 250, 125, 250, 125, 250, 125, 250, 125, 250, 125, 125, 250, 125, 250, 125, 250, 125, 250, 125, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 0
};

int win_melody[] = {
440, 0, 440, 330, 392, 440, 0, 0, 330, 0, 294, 278, 0, 220, 0, 196, 165, 0, 0, 587, 0, 587, 587, 494, 494, 440, 440, 587, 440, 440, 494, 494, 587, 587, 554, 0, 554, 554, 494, 494, 440, 0, 0, 0, 440, 494, 494, 523, 523, 554, 0, 554, 554, 494, 494, 440, 0, 0, 0, 554, 440, 440, 494, 554, 587, 0, 587, 587, 0, 587, 587, 587, 587, 0, 587, 587, 494, 494, 440, 440, 587, 440, 440, 494, 494, 587, 587, 554, 0, 554, 554, 494, 494, 440, 0, 0, 0, 440, 494, 494, 523, 523, 554, 0, 554, 554, 494, 494, 440, 0, 0, 0, 554, 440, 440, 494, 554, 587, 0, 587, 587, 0, 587, 587, 587, 0, 587, 784, 784, 784, 0, 0, 440, 740, 740, 740, 0, 0, 440, 659, 659, 659, 0, 740, 587, 587, 587, 659, 659, 740, 740, 0, 587, 784, 784, 784, 0, 0, 440, 740, 740, 740, 0, 0, 440, 659, 659, 659, 0, 587, 587, 587, 0, 0, 587, 0, 587, 587, 587, 587, 587, 0, 0, 0
};
int win_durations[] = {
250, 250, 250, 250, 250, 250, 500, 250, 250, 250, 250, 250, 250, 250, 250, 250, 1000, 250, 500, 375, 125, 250, 250, 250, 250, 500, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 500, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 500, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 375, 125, 250, 250, 250, 250, 500, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 500, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 500, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 750, 250, 250, 250, 250, 250, 750, 250, 250, 250, 250, 250, 750, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 750, 250, 250, 250, 250, 250, 750, 250, 250, 250, 250, 250, 750, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 125, 125, 250, 250, 250, 250, 1000, 0
};

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
DAC_HandleTypeDef hdac;

TIM_HandleTypeDef htim1;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart5;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_UART5_Init(void);
static void MX_DAC_Init(void);
static void MX_UART4_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */
int presForFrequency(int frequency);
void playTone(int *tone, int *duration, int *pause, int size);
void noTone(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void transmit_uart(char *string){
	uint8_t len = strlen(string);
	HAL_UART_Transmit(&huart2, (uint8_t*) string, len, 200);
}
int presForFrequency(int frequency){
	if (frequency == 0){
		return 0;
	}
	return ((TIM_FREQ / (ARR * frequency)) - 1);

}
void playTone(int *tone, int *duration, int *pause, int size){
	for (int i = 0; i < size; i++){
		if (!play_music) break;  // ← interrupción inmediata de la música

		int prescaler = presForFrequency(tone[i]);
		int dur = duration[i];
		int pauseBetweenTones = 0;

		if (pause != NULL)
			pauseBetweenTones = pause[i] - dur;

		__HAL_TIM_SET_PRESCALER(&htim1, prescaler);
		HAL_Delay(dur);
		noTone();
		HAL_Delay(pauseBetweenTones);
	}
}

void noTone(void){
	__HAL_TIM_SET_PRESCALER(&htim1, 0);  // prescaler 0

}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_FATFS_Init();
  MX_UART5_Init();
  MX_DAC_Init();
  MX_UART4_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */
  HAL_UART_Receive_IT(&huart5, &rxbuff5, 1);
  HAL_UART_Receive_IT(&huart4, &rxbuff4, 1);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  /* ----------------- JUGADOR 1 ----------------- */
	      if (flag5) {
	          transmit_uart("Jugador 1: ");
	          flag5 = 0; // Limpiamos flag

	          if (rxbuff5 == 0x42) { // 'B'
	              HAL_UART_Receive(&huart5, &dataB5, 1, HAL_MAX_DELAY);
	              if (dataB5 == 0x01){
	            	  transmit_uart("X\n");
	            	  play_music = !play_music;
	              }
	              else if (dataB5 == 0x02) transmit_uart("O\n");
	              else if (dataB5 == 0x04) transmit_uart("C\n");
	              else transmit_uart("null\n");
	          }
	          else if (rxbuff5 == 0x43) { // 'C'
	              HAL_UART_Receive(&huart5, &dataC5, 1, HAL_MAX_DELAY);
	              if (dataC5 == 0x01) transmit_uart("Arr\n");
	              else if (dataC5 == 0x02) transmit_uart("Aba\n");
	              else if (dataC5 == 0x04) transmit_uart("Der\n");
	              else if (dataC5 == 0x08) transmit_uart("Izq\n");
	              else transmit_uart("null\n");
	          }

	          /* Volvemos a activar interrupción */
	          HAL_UART_Receive_IT(&huart5, &rxbuff5, 1);
	      }

	      /* ----------------- JUGADOR 2 ----------------- */
	      if (flag4) {
	          transmit_uart("Jugador 2: ");
	          flag4 = 0; // Limpiamos flag

	          if (rxbuff4 == 0x42) { // 'B'
	              HAL_UART_Receive(&huart4, &dataB4, 1, HAL_MAX_DELAY);
	              if (dataB4 == 0x01) transmit_uart("X\n");
	              else if (dataB4 == 0x02) transmit_uart("O\n");
	              else if (dataB4 == 0x04) transmit_uart("C\n");
	              else transmit_uart("null\n");
	          }
	          else if (rxbuff4 == 0x43) { // 'C'
	              HAL_UART_Receive(&huart4, &dataC4, 1, HAL_MAX_DELAY);
	              if (dataC4 == 0x01) transmit_uart("Arr\n");
	              else if (dataC4 == 0x02) transmit_uart("Aba\n");
	              else if (dataC4 == 0x04) transmit_uart("Der\n");
	              else if (dataC4 == 0x08) transmit_uart("Izq\n");
	              else transmit_uart("null\n");
	          }

	          /* Volvemos a activar interrupción */
	          HAL_UART_Receive_IT(&huart4, &rxbuff4, 1);
	      }
	  if (play_music) {
		  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);
		  playTone(pokemon_intro_melody, pokemon_intro_durations, NULL, (sizeof(pokemon_intro_melody) / sizeof(pokemon_intro_melody[0])));
		  noTone();
		}
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief DAC Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC_Init(void)
{

  /* USER CODE BEGIN DAC_Init 0 */

  /* USER CODE END DAC_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC_Init 1 */

  /* USER CODE END DAC_Init 1 */

  /** DAC Initialization
  */
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT1 config
  */
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC_Init 2 */

  /* USER CODE END DAC_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 100-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 50;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief UART5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART5_Init(void)
{

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  huart5.Instance = UART5;
  huart5.Init.BaudRate = 115200;
  huart5.Init.WordLength = UART_WORDLENGTH_8B;
  huart5.Init.StopBits = UART_STOPBITS_1;
  huart5.Init.Parity = UART_PARITY_NONE;
  huart5.Init.Mode = UART_MODE_TX_RX;
  huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart5.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SD_SS_GPIO_Port, SD_SS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin : SD_SS_Pin */
  GPIO_InitStruct.Pin = SD_SS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
  HAL_GPIO_Init(SD_SS_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == UART5) {
        flag5 = 1; // Señalamos que llegó dato del jugador 1
    }
    else if (huart->Instance == UART4) {
        flag4 = 1; // Señalamos que llegó dato del jugador 2
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
